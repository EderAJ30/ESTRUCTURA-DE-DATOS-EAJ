package fes.aragon.pruebas;

import java.util.Scanner;

import fes.aragon.dinamica.listaCircular.ListaCircular;

//*Problema de lista circular "pedir la cadena"

public class ListaCircularCadena {

	public static void main(String[] args) {
		
		try (Scanner scanner = new Scanner(System.in)) {
			 
			ListaCircular<Character> listaCircularInicial = new ListaCircular<>();

			System.out.print("Ingresa una cadena: ");
			String cadenaInicial = scanner.nextLine();

			for (char cc : cadenaInicial.toCharArray()) {
			    listaCircularInicial.agregarEnColaC(cc);
			}

			for (int i = 0; i < cadenaInicial.length(); i++) {
			    listaCircularInicial.imprimirElementosC(); 
			    System.out.println("\n");
			    
			    listaCircularInicial.cabeza = listaCircularInicial.cabeza.getSiguiente();
			    listaCircularInicial.cola = listaCircularInicial.cola.getSiguiente();
			}
			listaCircularInicial.imprimirElementosC();
		}
	}
	
}
