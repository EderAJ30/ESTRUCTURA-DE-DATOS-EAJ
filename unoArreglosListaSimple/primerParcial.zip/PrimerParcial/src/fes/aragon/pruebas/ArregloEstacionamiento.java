package fes.aragon.pruebas;

import java.util.Random;

import fes.aragon.estatico.Arreglos;
import fes.aragon.excep.IndiceFueraDeRango;

public class ArregloEstacionamiento {
	
	public static void main(String[] args) {
			Arreglos<Integer> arg = new Arreglos<Integer>(20); 

			Random rd = new Random();
			for (int minuto = 0; minuto <= 60; minuto++) {
				System.out.println("Minuto: " + minuto);

				int num = rd.nextInt(100);
				int lugarlibre = Libre(arg);
				int valor = rd.nextInt(100);
				
				if (num >= 0 && num <= 50) {
					
					System.out.println("Entra");
					
					if (lugarlibre != -1) {
					
							try {
								//arg.insertar(valor); ESTA MAMABA EL CODIGO
								
								arg.asignar(lugarlibre, valor);
								arg.ordenamientoPivote(arg, lugarlibre + 1, valor);
							} catch (IndiceFueraDeRango e) {
								
								//e.printStackTrace();
							}
							
							
							
							System.out.println("============\n");
							System.out.println("Prueba, valor que debe entrar: "+valor);
							System.out.println("============\n");
						
					} else {
						System.out.println("El estacionamiento está lleno.");
					}
					arg.imprime();
					System.out.println("============\n");
				} else {
					System.out.println("Sale");
					int lugarOcupado = Ocupado(arg);
					
					if (lugarOcupado != -1) {
						try {
							
							System.out.println("============\n");
							System.out.println("Prueba, valor que debe salir: "+arg.recupera(lugarOcupado));
							System.out.println("============\n");
							arg.suprime(lugarOcupado);
						
						} catch (IndiceFueraDeRango e) {
						}
					} else {
						System.out.println("El estacionamiento está vacío.");
					}
					arg.imprime();
					System.out.println("============\n");
				}
			}
		}

		public static int Libre(Arreglos<Integer> a) {
			for (int i = 0; i < a.longitud(); i++) {
				try {
					if (a.recupera(i) == null) {
						return i;
					}
				} catch (IndiceFueraDeRango e) {
				}
			}
			return -1; 
		}

		public static int Ocupado(Arreglos<Integer> a) {
			for (int i = 0; i < a.longitud(); i++) {
				try {
					if (a.recupera(i) != null) {
						return i;
					}
				} catch (IndiceFueraDeRango e) {
				}
			}
			return -1; 
		}
	
}