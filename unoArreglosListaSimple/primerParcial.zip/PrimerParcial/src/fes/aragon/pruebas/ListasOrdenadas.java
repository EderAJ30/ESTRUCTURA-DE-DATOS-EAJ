package fes.aragon.pruebas;
import java.util.Random;

import fes.aragon.dinamica.listasimple.ListaSimple;
import fes.aragon.excep.IndiceFueraDeRango;

//4.-7 (1-600) para el tamaño,rango[-200,100]
//ESCRIBA UN PROGRAMA QUE LEA DOS LISTAS QUE SE ENCUENTREN ORDENADAS Y FORME UNA TERCERA QUE RESULTE DE LA MEZCLA DE LOS ELEMENTOS DE AMBAS LISTAS
public class ListasOrdenadas {
	public static void main(String[] args) {
	    ListaSimple<Integer> listaUno = new ListaSimple<>();
	    ListaSimple<Integer> listaDos = new ListaSimple<>();

	    Random random = new Random();

	 
	    int tamañoUno = random.nextInt(600) + 1;
	    for (int i = 0; i < tamañoUno; i++) {
	        listaUno.agregarEnCola(random.nextInt(301) - 200);
	    }


	    int tamañoDos = random.nextInt(600) + 1;
	    for (int i = 0; i < tamañoDos; i++) {
	        listaDos.agregarEnCola(random.nextInt(301) - 200);
	    }

	    ListaSimple<Integer> listaMezclada = new ListaSimple<>();

	    System.out.println("-----Lista uno-----");
	    listaUno.imprimirElementos();
	    System.out.println("\n-----Lista dos-----");
	    listaDos.imprimirElementos();

	    System.out.println("\n-----Lista mezclada-----");

	    boolean imprimir = true;

	    while (!listaUno.esVacia() && !listaDos.esVacia()) {
	        if (imprimir) {
	            System.out.println(listaUno.obtenerCabeza());
	            listaUno.eliminarEnCabeza();
	        } else {
	            System.out.println(listaDos.obtenerCabeza());
	            listaDos.eliminarEnCabeza();
	        }
	        imprimir = !imprimir;
	    }

	    // Imprimir los elementos restantes de la lista que aún tenga elementos
	    if (!listaUno.esVacia()) {
	        while (!listaUno.esVacia()) {
	            System.out.println(listaUno.obtenerCabeza());
	            listaUno.eliminarEnCabeza();
	        }
	    } else {
	        while (!listaDos.esVacia()) {
	            System.out.println(listaDos.obtenerCabeza());
	            listaDos.eliminarEnCabeza();
	        }
	    }
	}
}