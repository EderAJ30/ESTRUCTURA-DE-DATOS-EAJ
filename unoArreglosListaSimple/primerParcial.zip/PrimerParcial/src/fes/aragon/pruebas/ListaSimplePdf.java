package fes.aragon.pruebas;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import fes.aragon.dinamica.listasimple.ListaSimple;

//8.-Guardar en una lista simple un archivo pdf,
//y de nuevo construir el archivo. 

public class ListaSimplePdf {

    public static void main(String[] args) {

        try {
            ListaSimplePdf cp = new ListaSimplePdf();
            cp.copiarArchivo();
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private void copiarArchivo() throws IOException {
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Selecciona un archivo PDF");
            fileChooser.setFileFilter(new FileNameExtensionFilter("Archivos PDF", "pdf"));

            int result = fileChooser.showOpenDialog(null);

            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String nombreArchivo = selectedFile.getAbsolutePath();

                in = new FileInputStream(nombreArchivo);
                int numeroArchivos = 5;

                ListaSimple<byte[]> listaUno = new ListaSimple<>();

                byte[] datos = new byte[in.available()];
                in.read(datos);

                int numeroBytes = (datos.length / numeroArchivos);
                int contador = 0;
                int indiceArchivo = 1;

                while (contador < datos.length) {
                    String archivoSalida = nombreArchivo.replaceFirst(".pdf", "_" + indiceArchivo + ".pdf");
                    out = new FileOutputStream(archivoSalida);

                    byte[] datosArchivo = new byte[numeroBytes];
                    System.arraycopy(datos, contador, datosArchivo, 0, numeroBytes);

                    listaUno.agregarEnCola(datosArchivo);
                    listaUno.imprimirElementos();
                   
                    
                    
                    System.out.println("Archivo " + indiceArchivo + ": " + datosArchivo.length + " bytes");
                    
                    out.write(datosArchivo);
                    contador += numeroBytes;
                    indiceArchivo++;

                    if (indiceArchivo == numeroArchivos) {
                        numeroBytes = datos.length - contador;
                    }
                }

                String archivoSalidaFinal = nombreArchivo.replaceFirst(".pdf", "_NUEVO.pdf");
                out = new FileOutputStream(archivoSalidaFinal);

                for (int i = 1; i <= numeroArchivos; i++) {
                    String archivoEntrada = nombreArchivo.replaceFirst(".pdf", "_" + i + ".pdf");
                    in = new FileInputStream(archivoEntrada);

                    byte[] datosEntrada = new byte[in.available()];
                    in.read(datosEntrada);

                   
                    listaUno.obtenerCabeza();
                    listaUno.getLongitud();
                    listaUno.imprimirElementos();
                    out.write(datosEntrada);
                    
                }

                System.out.println("Tamaño del archivo final de salida: " + out.getChannel().size());

            }
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        
    }
}




