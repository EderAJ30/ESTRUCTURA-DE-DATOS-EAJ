package fes.aragon.pruebas;

//7

import java.util.Random;

import fes.aragon.dinamica.listasimple.ListaSimple;
import fes.aragon.excep.IndiceFueraDeRango;

public class ListaNegativoPositivo {

    public static void main(String[] args) {
    	
    	 ListaSimple<Integer> listaOriginal = new ListaSimple<>();
         ListaSimple<Integer> listaPositivos = new ListaSimple<>();
         ListaSimple<Integer> listaNegativos = new ListaSimple<>();


         Random random = new Random();
         int tamaño = random.nextInt(600); 

         for (int i = 0; i < tamaño; i++) {
             int numeroAleatorio = random.nextInt(300) - 200; 
             listaOriginal.agregarEnCola(numeroAleatorio);
         }
         
         for (int i = 0; i < listaOriginal.getLongitud(); i++) {
             try {
                 int numero = listaOriginal.obtenerNodo(i);
                 if (numero >= 0) {
                     listaPositivos.agregarEnCola(numero);
                 } else {
                     listaNegativos.agregarEnCola(numero);
                 }
             } catch (IndiceFueraDeRango e) {
                 e.printStackTrace();
             }
         }
         System.out.println("Lista original: \n");
         listaOriginal.imprimirElementos();
         
         System.out.println("Lista de números positivos: \n");
         listaPositivos.imprimirElementos();

         System.out.println("\nLista de números negativos: \n");
         listaNegativos.imprimirElementos();
         
    }
}


