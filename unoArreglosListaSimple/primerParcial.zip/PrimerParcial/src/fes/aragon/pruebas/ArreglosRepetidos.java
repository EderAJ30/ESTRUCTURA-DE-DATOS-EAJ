package fes.aragon.pruebas;

import java.util.Random;

import fes.aragon.estatico.Arreglos;

//2.-Lista de números repetidos de un arreglo
//(1000) tamaño, rango [-200,100]  (2 puntos)

public class ArreglosRepetidos {
	
	public static void main(String[] args) {
		
        Arreglos<Integer> arg = new Arreglos<Integer>(1000);
        
        try {
        	Random rd=new Random();
        	
        	for(int i =0; i < arg.longitud(); i++) {
	        		try {
	    				arg.insertar(rd.nextInt(301)-200);
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
        	}
        	
            int mayor = arg.recupera(0);
            int segundoMayor = arg.recupera(1);
            int promedio = 0;

            for (int i = 0; i < arg.longitud(); i++) {
                promedio += arg.recupera(i);

                int numero = arg.recupera(i);
                int contador = 0;
                
                for (int j = 0; j < arg.longitud(); j++) {
                    if (arg.recupera(j) == numero) {
                        contador++;
                    }
                }

                if (numero > mayor) {
                    int tmp = mayor;
                    mayor = numero;
                    segundoMayor = tmp;
                }
                
                if (numero > segundoMayor && numero != mayor) {
                    segundoMayor = numero;
                }
                
                System.out.println("El número " + numero + " de la lista se repite " + contador + " veces");
                
            }

            promedio /= arg.longitud();

            System.out.println("El numero mayor es: " + mayor);
            System.out.println("El Segundo numero mayor es: " + segundoMayor);
            System.out.println("El promedio de los numeros es: " + promedio);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
