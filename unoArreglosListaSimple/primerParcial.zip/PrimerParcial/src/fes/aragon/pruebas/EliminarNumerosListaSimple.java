package fes.aragon.pruebas;

import java.util.Random;

import fes.aragon.dinamica.listasimple.ListaSimple;
import fes.aragon.excep.IndiceFueraDeRango;

/*7.-*Escribe un programa que elimine los elementos
repetidos de una lista simple, y los elementos
repetidos pasarlos a una lista nueva para desplegarlos.
Nota: Llenar la lista con números aleatorios
con un rango de [1,500],(1-600) para el tamaño*/

public class EliminarNumerosListaSimple {

    public static void main(String[] args) {

        ListaSimple<Integer> listaInicial = new ListaSimple<>();
        ListaSimple<Integer> listaInicialNueva = new ListaSimple<>();
        
        Random random = new Random();
        int tamaño = random.nextInt(600); 
        
	        for (int i = 0; i < tamaño; i++) {
	        	int numeroAleatorio = random.nextInt(500) + 1; 
	        		listaInicial.agregarEnCola(numeroAleatorio);
	        }

        for (int i = 0; i < listaInicial.getLongitud(); i++) {
        	
            try {
                int dato = listaInicial.obtenerNodo(i);
                	boolean repetido = false;

                for (int j = 0; j < i; j++) {
                    int elementoAnterior = listaInicial.obtenerNodo(j);
                    	if (elementoAnterior == dato) {
                    		repetido = true;
                    			break;
                    }
                }
 
                if (repetido) {
                    	listaInicialNueva.agregarEnCola(dato);
                }
            } catch (IndiceFueraDeRango e) {
                e.printStackTrace();
            }
        }
        
        System.out.println("Lista Simple Inicial:\n");
        listaInicial.imprimirElementos();
        System.out.println("\nElementos que se repiten en la Lista Simple Inicial:\n");
        listaInicialNueva.imprimirElementos();
        
    }
}
