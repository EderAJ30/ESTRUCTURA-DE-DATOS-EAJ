package fes.aragon.dinamica.listaCircular;

import fes.aragon.dinamica.listasimple.Nodo;

/*
 * LISTACIRCULAR.java
 * Integrantes del equipo
 * 1.- Avalos Juarez Eder
 * 2.- Briones Cardenas Juan Carlos
 * 3.- Manzano Mejia Itandehui
 * 4.- Ramirez Picazo Bruno
 */

public class ListaCircular<E> {
	
	public Nodo<E> cabeza, cola;
	protected int longitud = 0;
	
	public ListaCircular() {
		cabeza = cola = null;
	}
	
	/*
	 * Metodo que agrega nuevo elemento al inicio de la lista circular
	 * @param dato: El elemento de tipo E a agregar al inicio de la lista.
	 */
	public void agregarEnCabezaC(E dato) {
	    Nodo<E> nuevoNodo = new Nodo<E>(dato);
	    if (cabeza == null) {
	        cabeza = cola = nuevoNodo;
	        cabeza.setSiguiente(cola); 
	    } else {
	        nuevoNodo.setSiguiente(cabeza);
	        cabeza = nuevoNodo;
	        cola.setSiguiente(cabeza); 
	    }
	    longitud++;
	}

	
	/**
	 * Método que agrega un valor al final de la lista circular.
	 * @param dato es el nuevo valor que se agregará al final de la lista.
	 */
	public void agregarEnColaC(E dato) {
		Nodo<E> nuevoNodo = new Nodo<E>(dato);
		if (cabeza == null) {
			cabeza = cola = nuevoNodo;
			cola.setSiguiente(cabeza); 
		} else {
			cola.setSiguiente(nuevoNodo);
			cola = nuevoNodo;
			cola.setSiguiente(cabeza); 
		}
		longitud++;
	}
	
	/**
	 * Método que imprime los elementos de la lista circular.
	 * 
	 */
	public void imprimirElementosC() {
		if (cabeza == null) {
			System.out.println("error");
		} else {
			Nodo<E> tmp = cabeza;
			do {
				System.out.println(tmp.getDato());
				tmp = tmp.getSiguiente();
			} while (tmp != cabeza);
		}
	}	
}
