package fes.aragon.dinamica.listasimple;

import fes.aragon.excep.IndiceFueraDeRango;

/*
 * LISTASIMPLE.java
 * Integrantes del equipo
 * 1.- Avalos Juarez Eder
 * 2.- Briones Cardenas Juan Carlos
 * 3.- Manzano Mejia Itandehui
 * 4.- Ramirez Picazo Bruno
 */

public class ListaSimple<E> {
	protected Nodo<E> cabeza ,cola;
	protected int longitud = 0;
	
	public ListaSimple() {
		cabeza = cola = null;
	}
	
	/**
	 *Metodo que agrega un valor en la parte inicial del arreglo
	 * @param dato es un nuevo valor que recibe el arreglo para agregarlo al inicio  
	 */
	public void agregarEnCabeza(E dato) {
		cabeza = new Nodo<E>(dato, cabeza);
		if(cola == null) {
			cola = cabeza;
		}
		longitud++;
	}
	
	/**
	 * Metodo que agrega un valor en la parte final del arreglo 
	 * @param dato es el nuevo valor que se agregara al final del arreglo 
	 */
	public void agregarEnCola(E dato) {
		if (cabeza == null) {
			cabeza = cola = new Nodo<E>(dato);
		}else {
			cola.setSiguiente(new Nodo<E>(dato));
			cola = cola.getSiguiente(); 
		}
		longitud++;
	}
	
	/**
	 * Metodo que llama a todo el arreglo para imprimirlo
	 */
	public void imprimirElementos() {
		for(Nodo<E> tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
			System.out.println(tmp.getDato());
		}
	}
	
	/*
	 * Devuelve true si la lista es vacia si no es falso 
	 * 
	 * @return True si es vacia False si no es vacia
	 */
	public boolean esVacia() {
		if (longitud == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Metodo que manda a llamar al dato que se encuentra en la posicion inicial del arreglo 
	 * @return regresa el dato inicial 
	 */
	public E obtenerCabeza() {
		return cabeza.getDato();
	}
	 
	/**
	 * Metodo que manda a llamar al ultimo dato del arreglo 
	 * @return regresa el ultimo dato 
	 */
	public E obtenerCola() {
		return cola.getDato();
	}
	
	/**
	 * Metodo que elimina un dato en cualquier posicion del arreglo
	 * @param dato es el valor que se busca eliminar del arreglo 
	 * @return devuelve el valor borrado en caso de haber eliminado exitosamente el dato 
	 */
	public boolean eliminar(E dato) {
		boolean borrado = false;
		if (cabeza != null) {
			if (cabeza == cola &&
					dato.equals(cabeza.getDato())) {
				cabeza = cola = null;
				borrado = true;
				longitud--;
			}else if (dato.equals(cabeza.getDato())) {
				cabeza = cabeza.getSiguiente();
				borrado  = true;
				longitud--;
			} else {
				Nodo<E> prd, tmp;
				for(prd = cabeza,tmp = 
					   cabeza.getSiguiente(); 
					   tmp != null 
					   && 
					   !tmp.getDato()
					   .equals(dato);
						prd = prd.getSiguiente(),
					tmp = tmp.getSiguiente())
					;
				if (tmp != null) {
					borrado = true;
					longitud--;
					prd.setSiguiente
					(tmp.getSiguiente());
					if (tmp == cola) {
						cola = prd;
					}
				}
			}
		}
		return borrado;
	}

	/**
	 * Indica si un elemento esta en la lista
	 *
	 * @param x Dato a buscar
	 * @return Retorna el indice si lo encuentra sino un -1
	 */
	public int estaEnLista(E x) {
		int aux = 0;
		for (Nodo<E> tmp = cabeza; tmp != null; tmp = tmp.getSiguiente(), aux++) {
			if (tmp.getDato().equals(x)) {
				break;
			}
		}
		if (aux < longitud) {
			return aux;
		} else {
			return -1;
		}

	}
	
	/**
	 * Metodo que devuelve el valor del nodo indicado
	 *
	 * @param i Indice a obtener
	 * @return Valor del nodo
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public E obtenerNodo(int i) throws IndiceFueraDeRango {
		int aux = 0;
		E e = null;
		if (i < longitud && i >= 0) {
			for (Nodo<E> tmp = cabeza; aux <= i; tmp = tmp.getSiguiente(), aux++) {
				e = (E) tmp.getDato();
			}
		} else {
			throw new IndiceFueraDeRango("Error");
		}

		return e;
	}
	
	/**
	 * Inserta un dato en el indice indicado
	 *
	 * @param dato Dato a agregar
	 * @param i    indice a insertar
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public void insertarEnIndice(E dato, int i) throws IndiceFueraDeRango {
		if (i == 0) {
			agregarEnCabeza(dato);
		} else if (i > 0 && i < longitud) {
			Nodo<E> tmp;
			int aux = 0; 
			for (tmp = cabeza; aux < i; tmp = tmp.getSiguiente(), aux++);
			Nodo<E> tmp2 = new Nodo<E>(tmp.getDato(), tmp.getSiguiente());
			tmp.setDato(dato);
			tmp.setSiguiente(tmp2);
			if (i == getLongitud() - 1) {
				cola = tmp2;
			}
			longitud++;
		} else {
			throw new IndiceFueraDeRango("Error ");
		}
	}

	/**
	 * Cambia la primera incidencia de dato con el nuevo dato si el boolean es true
	 * cambiara todos los datos si es False solo la primera coincidencia
	 *
	 * @param dato      Data a cambiar
	 * @param nuevoDato Dato que remplaza al dato anterior
	 * @param condicion True: todas las coincidencias False: solo la primera
	 *                  coincidencia
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	@SuppressWarnings("unchecked")
	public void asignarB(Object dato, Object nuevoDato, boolean condicion) throws IndiceFueraDeRango {
		if (condicion == false) {
			for (Nodo<E> tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
				((ListaSimple<Object>) tmp.getDato()).asignar(dato, nuevoDato, condicion);
			}
		} else {
			for (Nodo<E> tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
				((ListaSimple<Object>) tmp.getDato()).asignar(dato, nuevoDato, condicion);
			}
		}
	}
	
	/**
	 * Metodo nos da la longitud del arreglo 
	 * @return regresa la longitud
	 */
	public int getLongitud() {
		if (longitud < 0) {
			longitud = 0;
		}
		return longitud;
	}
	
	/**
	 *Metodo que elimina el valor en la cabeza del arreglo 
	 */
	public void eliminarEnCabeza() {
		if (cabeza != null) {
			if (cabeza == cola ) {
				cabeza= cola = null;
				longitud--;
			} else {
				cabeza = cabeza.getSiguiente();
				longitud--;
			}
		}
	}
	
	/**
	 * metodo que elimina el valor de la cola en el arreglo
	 */
	@SuppressWarnings("unused")
	public void eliminarEnCola() {
		if (cabeza != null) {
			if(cabeza == cola) {
				cabeza = cola = null;
				longitud--;
			}else {
				Nodo<E> tmp;
				for(tmp = cabeza;
						tmp.getSiguiente()!=cola;
						tmp=tmp.getSiguiente()) 
					;
				tmp.setSiguiente(null);
				cola = tmp;
				longitud--;
			}
		}
	} 

	/*
	 * metodo para cambiar cualquier valor, solo da el valor donde quieres cambiarlo
	 */
	public void asignar (E dato, E nuevoDato, boolean b) {
		if (cabeza != null) {
			if (!b) {
				Nodo<E> tmp;
				for (tmp = cabeza;
						!tmp.getDato().equals(dato)
						&& tmp.getSiguiente() != null; tmp = tmp.getSiguiente());
					tmp.setDato(nuevoDato);
			}
		} else {
			Nodo<E> tmp;
			for (tmp = cabeza; tmp.getSiguiente() != null; tmp = tmp.getSiguiente()) {
				if (tmp.getDato().equals(dato)) {
					tmp.setDato(nuevoDato);
				}
			}
			
			if(tmp.getDato().equals(dato)) {
				tmp.setDato(nuevoDato);
			}
		}
	}
	
}
