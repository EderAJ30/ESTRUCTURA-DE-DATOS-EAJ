package fes.aragon.dinamica.listasimple;

/*
 * Nodo.java
 * Integrantes del equipo
 * 1.- Avalos Juarez Eder
 * 2.- Briones Cardenas Juan Carlos
 * 3.- Manzano Mejia Itandehui
 * 4.- Ramirez Picazo Bruno
 */

/*
 * Clase Nodo para utilizar en Herramientas de ListaSimple
 */
public class Nodo<E> {
	
	private E dato;
	private Nodo<E> siguiente;
	
	/*
	 * Se inicializan los campos
	 */
	public Nodo(E dato) {
		this (dato, null);
	}
	
	public Nodo(E dato, Nodo<E> siguente) {
		this.dato=dato;
		this.siguiente=siguente;
	}

	public E getDato() {
		return dato;
	}

	public void setDato(E dato) {
		this.dato = dato;
	}

	public Nodo<E> getSiguiente() {
		return siguiente;
	}

	public void setSiguiente(Nodo<E> siguente) {
		this.siguiente = siguente;
	}
	
}
 

