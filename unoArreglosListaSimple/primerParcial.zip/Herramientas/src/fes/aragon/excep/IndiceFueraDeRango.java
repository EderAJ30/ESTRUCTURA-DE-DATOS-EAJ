package fes.aragon.excep;

/**
 *The Class IndiceFueraDeRango
 */
public class IndiceFueraDeRango extends Exception{
	private static final long serialVersionUID =1L;
	
	public IndiceFueraDeRango(String msg) {
		super(msg);
	}
}
