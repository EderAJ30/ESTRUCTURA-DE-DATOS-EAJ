package fes.aragon.estatico;

import java.util.Iterator;

import fes.aragon.excep.IndiceFueraDeRango;

/**
 * Herramienta para crear Un Arreglo Sencillo de cualquier tipo
 * 
 *
 *
 * @param <E> Tipo del arreglo
 */
public class Arreglos <E>{
	private int indice=0;
	private final Object[] l;
	
	/**
	 * Constructor donde se indica el numero de elementos que se desea en el arreglo
	 * 
	 * @param numeroElementos NUmero de elementos en el arreglo
	 */
	public Arreglos(int numeroElementos) {
		this.l=new Object[numeroElementos];
	}
	
	/**
	 * Metodo que inserta un valor al arreglo
	 * 
	 * @param x Valor a insertar
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public void insertar (E x) throws IndiceFueraDeRango{
		if (indice<l.length) {
			l[indice]=x;
			indice++;
		} else {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}
	}
	
	/**
	 * Devuelve la posicion de un elemento de un valor localizado en el arreglo
	 * 
	 * @param x Valor a encontrar
	 * @return Devuelve la posicion del elemento localizado
	 */
	public Integer localiza(E x) {
		for (int i = 0; i < l.length; i++) {
			if (l[i].equals(x)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Funcion que devuelve el valor del arreglo pasando el indice
	 * 
	 * @param p indice del arreglo
	 * @return Valor localizado en el indice p del arreglo
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public E recupera(int p) throws IndiceFueraDeRango{
		if (p>l.length||p<0) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		} else {
			@SuppressWarnings("unchecked")
			final E e=(E)l[p];
			return e;
		}
	}
	
	/**
	 * Metodo para borrar el elemento pasando su indice
	 * 
	 * @param p Indice a eliminar
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public void suprime (int p) throws IndiceFueraDeRango{
		if (p>l.length||p<0) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		} else {
			l[p]=null;
			indice--;
		}
	}
	
	/**
	 * Metodo que devuelve el valor del siguiente indice al mandado
	 * 
	 * @param p Indice
	 * @return devuelve el valor siguiente
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public E siguiente(int p)throws IndiceFueraDeRango{
		if (p==l.length||p<-1) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}
		@SuppressWarnings("unchecked")
		final E e=(E)l[p+1];
		return e;
	}
	
	/**
	 * Metodo que regresa el valor del indice anterior al mandado
	 * 
	 * @param p Indice mandado
	 * @return Devulve el valor anterior
	 * @throws IndiceFueraDeRango Advertencia de rango
	 */
	public E anterior(int p)throws IndiceFueraDeRango{
		if (p==l.length-1||p<-1) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		}
		@SuppressWarnings("unchecked")
		final E e=(E)l[p-1];
		return e;
	}
	
	/**
	 * Metodo que limpia la lista mandadoa
	 * 
	 */
	public void limpiar() {
		for (int i = 0; i < l.length; i++) {
			l[i]=null;
		}
	}
	
	/**
	 * Devuelve el primer valor del arreglo
	 * 
	 * @return Primer valor de la lista
	 */
	public void imprime() {
		for (int i = 0; i < l.length; i++) {
			System.out.println(l[i]);
		}
		System.out.println();
	}
	
	/*
	 * Metodo que asigna valor al arreglo
	 */
	public void asignar(int p, E x)throws IndiceFueraDeRango{
		if (p>l.length||p<0) {
			throw new IndiceFueraDeRango("Indice fuera de rango");
		} else {
			l[p]=x;
		}
	}
	
	/*
	 * El ordenamiento se realiza desde el principio del arreglo hasta que el valor
 	 * en la posición 0 sea igual al valor pivote.
	 */
	public static void ordenamientoPivote(Arreglos<Integer> n, int longitudPivote, int pivote) {
		try {
			if (longitudPivote>0) {
				
				for (int i = 0; !n.recupera(0).equals(pivote); i++) {
					
					for (int j = 0; j < longitudPivote-1; j++) {
						Integer temp=n.recupera(j);
						n.asignar(j, n.recupera(j+1));
						n.asignar(j+1, temp);
						
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Metodo que devuelve la longitud del arreglo
	 * 
	 * @return retorna la longitud del arreglo
	 */
	public Integer longitud() {
		return l.length;
	}
}